# Shadow System — projeto Android

Aplicativo local de treino inspirado na estética de sistemas RPG.

## Funcionalidades
- Painel de nível, XP e atributos gamificados
- Rotina de cinco dias com séries e repetições
- Marcação de exercícios e conclusão de missões
- XP diário, conquistas e sequência de atividade
- Registro de peso e medidas corporais
- Revisão semanal e exportação de backup JSON
- Dados salvos localmente no aparelho via armazenamento do WebView

## Como gerar o APK
1. Abra a pasta `ShadowSystem` no Android Studio.
2. Aguarde a sincronização do Gradle.
3. Instale Android SDK Platform 35 e JDK 17 se solicitados.
4. Selecione **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O APK de debug será gerado em `app/build/outputs/apk/debug/app-debug.apk`.

Este pacote contém o código-fonte do projeto. O APK ainda precisa ser compilado no Android Studio; não foi compilado nem testado neste ambiente.
